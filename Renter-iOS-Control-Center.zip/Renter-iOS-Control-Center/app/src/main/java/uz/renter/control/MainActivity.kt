package uz.renter.control

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 26)
    private val tile = Color.rgb(30, 42, 63)
    private val blue = Color.rgb(74, 139, 255)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 22): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD }
    private fun button(label: String, icon: String, color: Int = tile, action: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            background=shape(color, 22); setPadding(dp(10),dp(13),dp(10),dp(12))
            isClickable=true; isFocusable=true; setOnClickListener { action() }
        }
        box.addView(text(icon, 25f))
        box.addView(text(label, 12f, Color.WHITE, true).apply { gravity=Gravity.CENTER; setPadding(0,dp(6),0,0) })
        return box
    }
    private fun addTileRow(parent: LinearLayout, items: List<LinearLayout>) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        items.forEachIndexed { i, v ->
            val p=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(if(i==0)0 else dp(5),0,if(i==items.lastIndex)0 else dp(5),0) }
            p.addView(v, LinearLayout.LayoutParams(-1,dp(105)))
            row.addView(p, LinearLayout.LayoutParams(0,-2,1f))
        }
        parent.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=bg
        val scroll=ScrollView(this).apply { setBackgroundColor(bg) }
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(25),dp(20),dp(22)) }
        scroll.addView(root); setContentView(scroll)
        root.addView(text("RENTER", 13f, Color.rgb(143,178,255), true))
        root.addView(text("Control Center", 31f, Color.WHITE, true).apply { setPadding(0,dp(4),0,dp(5)) })
        root.addView(text("iOS 18 inspired • Android 11", 13f, Color.LTGRAY))
        val clock=text(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date()), 48f, Color.WHITE, true)
        clock.setPadding(0,dp(22),0,dp(5)); root.addView(clock)
        root.addView(text(java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale("uz")).format(java.util.Date()),15f,Color.LTGRAY))
        val gap=View(this); root.addView(gap,LinearLayout.LayoutParams(1,dp(22)))
        addTileRow(root,listOf(
            button("Wi-Fi","◉",blue){ startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) },
            button("Bluetooth","ᛒ"){ startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            button("Internet","▥"){ startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        ))
        addTileRow(root,listOf(
            button("Fonarik","▣"){ try { startActivity(Intent("android.intent.action.MAIN").setClassName("com.android.settings","com.android.settings.Settings")) } catch(_:Exception){ startActivity(Intent(Settings.ACTION_SETTINGS)) } },
            button("Ovoz","♫"){ startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) },
            button("Sozlamalar","⚙"){ startActivity(Intent(Settings.ACTION_SETTINGS)) }
        ))
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=shape(tile,24); setPadding(dp(18),dp(16),dp(18),dp(16)) }
        card.addView(text("☀  Yorqinlik",16f,Color.WHITE,true))
        val seek=SeekBar(this).apply { max=255; progress=android.provider.Settings.System.getInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,120) }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?, p:Int, user:Boolean) {}
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        })
        card.addView(seek); root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)})
        val music=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=shape(tile,24); setPadding(dp(18),dp(16),dp(18),dp(16)) }
        music.addView(text("♫  Musiqa boshqaruvi",17f,Color.WHITE,true))
        music.addView(text("Musiqa ilovasini ochish uchun bosing",13f,Color.LTGRAY).apply{setPadding(0,dp(8),0,dp(0))})
        music.setOnClickListener { try { startActivity(packageManager.getLaunchIntentForPackage("com.google.android.youtube.music") ?: Intent(Settings.ACTION_SETTINGS)) } catch(_:Exception){} }
        root.addView(music)
        root.addView(text("Eslatma: bu hozircha mustaqil boshqaruv paneli maketi. Yuqoridan suriladigan haqiqiy tizim panelini almashtirmaydi.",12f,Color.GRAY).apply{setPadding(2,dp(18),2,0)})
    }
}
