# Renter iOS Control Center

Tecno Spark 8P / Android 11 uchun iOS 18 uslubidan ilhomlangan Android loyiha.

## Build
Android Studio'da loyihani oching va Gradle Sync qiling. So'ng Build > Build APK(s).

## Muhim cheklov
Bu boshlang'ich loyiha ilova ichida ishlaydigan Control Center maketidir. Android uchinchi tomon ilovasiga tizimning haqiqiy quick settings panelini to'liq almashtirishga ruxsat bermaydi. Wi-Fi, Bluetooth va boshqa tugmalar tegishli Android sozlamalarini ochadi. Yorqinlik slayderi hozircha display settings oynasiga olib boradi.

## Texnologiya
- Kotlin
- Android SDK
- Min SDK 23
